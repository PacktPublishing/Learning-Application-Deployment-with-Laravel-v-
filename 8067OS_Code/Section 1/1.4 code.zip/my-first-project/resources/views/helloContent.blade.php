@extends ('helloLayout')

@section ('content')
    <p><?php echo $p; ?></p>
@stop
